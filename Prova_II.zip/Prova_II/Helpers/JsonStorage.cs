using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;

public static class JsonStorage<T>
{
    private static string GetFilePath(string fileName)
    {
        return Path.Combine("Data", fileName);
    }

    public static List<T> Load(string fileName)
    {
        var path = GetFilePath(fileName);
        if (!File.Exists(path)) return new List<T>();

        var json = File.ReadAllText(path);
        return JsonConvert.DeserializeObject<List<T>>(json);
    }

    public static void Save(List<T> list, string fileName)
    {
        var path = GetFilePath(fileName);
        var json = JsonConvert.SerializeObject(list, Formatting.Indented);
        File.WriteAllText(path, json);
    }
}