using System.ComponentModel.DataAnnotations;

public class Cliente
{
    public int Id { get; set; }

    [Required]
    [Display(Name = "CPF/CNPJ")]
    public string CodigoFiscal { get; set; } = string.Empty;

    [Required]
    [MaxLength(15)]
    [Display(Name = "Inscrição Estadual")]
    public string InscricaoEstadual { get; set; } = string.Empty;

    [Required]
    public string Nome { get; set; } = string.Empty;

    public string? NomeFantasia { get; set; }

    public string? Endereco { get; set; }

    public string? Numero { get; set; }

    public string? Bairro { get; set; }

    [Required]
    public string Cidade { get; set; } = string.Empty;

    [Required]
    public string Estado { get; set; } = string.Empty;

    [Display(Name = "Data de Nascimento / Abertura")]
    public DateTime DataNascimento { get; set; }

    public string? ImagemPath { get; set; }
}