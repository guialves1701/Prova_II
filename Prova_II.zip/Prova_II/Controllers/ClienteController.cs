using Microsoft.AspNetCore.Mvc;
using Prova_II.Models;
using System.Linq;

public class ClienteController : Controller
{
    private const string FileName = "clientes.json";

    private bool UsuarioAutenticado()
    {
        return HttpContext.Session.GetInt32("UsuarioId") != null;
    }

    public IActionResult Index()
    {
        if (!UsuarioAutenticado())
            return RedirectToAction("Login", "Usuario");

        var clientes = JsonStorage<Cliente>.Load(FileName);
        return View(clientes);
    }

    public IActionResult Form(int? id)
    {
        if (!UsuarioAutenticado())
            return RedirectToAction("Login", "Usuario");

        var clientes = JsonStorage<Cliente>.Load(FileName);
        var cliente = id == null ? new Cliente() : clientes.FirstOrDefault(c => c.Id == id);
        return View(cliente);
    }

    [HttpPost]
    public IActionResult Form(Cliente cliente, IFormFile imagem)
    {
        if (!UsuarioAutenticado())
            return RedirectToAction("Login", "Usuario");

        var clientes = JsonStorage<Cliente>.Load(FileName);

        // Validação de CPF/CNPJ e IE únicos
        bool duplicado = clientes.Any(c =>
            c.Id != cliente.Id &&
            (c.CodigoFiscal == cliente.CodigoFiscal || c.InscricaoEstadual == cliente.InscricaoEstadual)
        );

        if (duplicado)
        {
            ModelState.AddModelError("", "Código Fiscal ou Inscrição Estadual já cadastrados.");
            return View(cliente);
        }

        // Upload da imagem (opcional)
        if (imagem != null && imagem.Length > 0)
        {
            var path = Path.Combine("wwwroot/imagens", imagem.FileName);
            using (var stream = new FileStream(path, FileMode.Create))
            {
                imagem.CopyTo(stream);
            }
            cliente.ImagemPath = "/imagens/" + imagem.FileName;
        }

        if (cliente.Id == 0)
        {
            cliente.Id = clientes.Count > 0 ? clientes.Max(c => c.Id) + 1 : 1;
            clientes.Add(cliente);
        }
        else
        {
            var index = clientes.FindIndex(c => c.Id == cliente.Id);
            if (index != -1)
                clientes[index] = cliente;
        }

        JsonStorage<Cliente>.Save(clientes, FileName);
        return RedirectToAction("Index");
    }

    public IActionResult Delete(int id)
    {
        if (!UsuarioAutenticado())
            return RedirectToAction("Login", "Usuario");

        var clientes = JsonStorage<Cliente>.Load(FileName);
        clientes.RemoveAll(c => c.Id == id);
        JsonStorage<Cliente>.Save(clientes, FileName);
        return RedirectToAction("Index");
    }

    public IActionResult Exportar(int id)
    {
        var clientes = JsonStorage<Cliente>.Load(FileName);
        var cliente = clientes.FirstOrDefault(c => c.Id == id);
        if (cliente == null) return NotFound();

        var json = Newtonsoft.Json.JsonConvert.SerializeObject(cliente, Newtonsoft.Json.Formatting.Indented);
        return File(System.Text.Encoding.UTF8.GetBytes(json), "application/json", $"cliente_{id}.json");
    }
}
