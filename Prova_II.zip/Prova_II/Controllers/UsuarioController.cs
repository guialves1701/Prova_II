using Microsoft.AspNetCore.Mvc;
using Prova_II.Models;
using System.Linq;

public class UsuarioController : Controller
{
    private const string FileName = "usuarios.json";

    public IActionResult Cadastro()
{
    return View();
}

[HttpPost]
public IActionResult Cadastro(Usuario usuario)
{
    var usuarios = JsonStorage<Usuario>.Load("usuarios.json");

    // Verifica se já existe esse e-mail
    if (usuarios.Any(u => u.Email == usuario.Email))
    {
        ModelState.AddModelError("", "Este e-mail já está cadastrado.");
        return View(usuario);
    }

    usuario.Id = usuarios.Count > 0 ? usuarios.Max(u => u.Id) + 1 : 1;
    usuario.SenhaHash = PasswordHasher.Hash(usuario.SenhaHash);
    usuarios.Add(usuario);

    JsonStorage<Usuario>.Save(usuarios, "usuarios.json");

    return RedirectToAction("Login");
}

    [HttpPost]
    public IActionResult Login(string email, string senha)
    {
        var usuarios = JsonStorage<Usuario>.Load(FileName);
        var user = usuarios.FirstOrDefault(u => u.Email == email);

        if (user == null || !PasswordHasher.Verify(senha, user.SenhaHash))
        {
            ModelState.AddModelError("", "E-mail ou senha inválidos.");
            return View();
        }

        // Armazenar em sessão
        HttpContext.Session.SetInt32("UsuarioId", user.Id);
        return RedirectToAction("Index", "Cliente");
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Login");
    }
}